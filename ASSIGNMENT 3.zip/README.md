# Java Assignment 3 – CO3
## Exception Handling and Multithreading (Q1–Q7)

Each task folder contains a Java source file and a sample output screenshot (`output_screenshot.png`) and text output (`output.txt`).

### Compile and run
Open a terminal in the task folder:
```bash
javac FileName.java
java ClassName
```
For Q1, use sample values when prompted. Sample outputs are illustrative; thread scheduling and timing can vary by system.

### Tasks
- Q1: ATM withdrawal exception handling
- Q2: Custom exceptions and chaining
- Q3: Try-with-resources
- Q4: Thread lifecycle (`Thread` and `Runnable`)
- Q5: Synchronized seat booking
- Q6: Producer-consumer and deadlock-safe transfers
- Q7: Concurrent result processing with `ExecutorService`, `Callable`, and `Future`
