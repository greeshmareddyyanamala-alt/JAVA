# Java Assignment 5 – CO5 (Files and Databases)

Folders are organized by task. Each folder contains Java source, sample output, and a terminal-style output screenshot. JDBC tasks use a local MySQL database only; configure credentials in the source before running.

**Java:** Java 17+ recommended. Compile/run standalone programs: `javac File.java` then `java ClassName`.

## Tasks
- A1: file format design notes
- A2: buffered vs unbuffered line counting
- A3: generic DAO example
- A4: serialization/transient demonstration
- A5: transaction and parameterized-query design notes
- B1: pass store + line-count benchmark
- B2: safe PreparedStatement login example (local toy DB; configure driver/database)
- B3: batch transactional loader (JDBC; configure DB)
- B4: file-to-database migration + metadata (JDBC; configure DB)

Benchmarks are illustrative runs on the current environment; rerun on your own machine and record your measurements. Database examples require a JDBC driver and a local database schema.
