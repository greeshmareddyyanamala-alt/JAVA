import java.io.*;
public class BufferedLineCounter {
  static long countUnbuffered(File f) throws IOException { long n=0; try(FileInputStream in=new FileInputStream(f)){ int b; while((b=in.read())!=-1) if(b=='\n') n++; } return n; }
  static long countBuffered(File f) throws IOException { long n=0; try(BufferedInputStream in=new BufferedInputStream(new FileInputStream(f))){ int b; while((b=in.read())!=-1) if(b=='\n') n++; } return n; }
  public static void main(String[] args) throws Exception { File f=File.createTempFile("log", ".txt"); try(Writer w=new FileWriter(f)){ for(int i=0;i<100000;i++) w.write("attendance row\n"); } long t=System.nanoTime(); long a=countUnbuffered(f); long u=System.nanoTime()-t; t=System.nanoTime(); long b=countBuffered(f); long v=System.nanoTime()-t; System.out.println("Unbuffered lines: "+a+" time(ms): "+u/1e6); System.out.println("Buffered lines: "+b+" time(ms): "+v/1e6); f.delete(); }
}
