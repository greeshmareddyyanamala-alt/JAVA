# A5 Transaction & PreparedStatement
```text
con.setAutoCommit(false)	ry:
  debit source wallet by 500
  credit destination wallet by 500
  con.commit()
catch SQLException:
  con.rollback()
finally:
  restore auto-commit
```
Use PreparedStatement placeholders for login values; do not concatenate user input into SQL. Example: SELECT id FROM users WHERE id=? AND pwd=? and bind both values. Transaction gives atomicity; two auto-commit statements could leave only one wallet updated if the second fails.
