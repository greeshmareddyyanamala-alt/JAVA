import java.sql.*;
// Toy JDBC login check. Configure a local test database and JDBC driver.
public class PreparedLogin { static boolean login(Connection c,String id,String password)throws SQLException{String sql="SELECT 1 FROM users WHERE id=? AND pwd=?";try(PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,id);ps.setString(2,password);try(ResultSet rs=ps.executeQuery()){return rs.next();}}} public static void main(String[]a){System.out.println("Example uses parameterized values; set up local JDBC connection before testing.");}}
