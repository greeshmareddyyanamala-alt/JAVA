# A1 File Format Design
## Text layout
passId,regNo,name,routeNo,amount,date,boardingStop
- UTF-8 CSV-like delimited format; quote fields containing commas and double quotes.
- Append new records; search/list are sequential scans.
## Binary layout
DataOutputStream: UTF passId, UTF regNo, UTF name, int routeNo, UTF boardingStop, UTF validityDate, double amount. Use UTF lengths for variable text fields.
## Pseudocode
ADD: open BufferedWriter in append mode; validate; encode fields; write line; close.
FIND: open BufferedReader; read each line; parse safely; skip malformed; compare passId; return record or not-found.
LIST_ROUTE: scan records; parse valid rows; print records whose routeNo equals requested route.
## Damaged data
Skip/report malformed rows; missing file gives clear message or create on add; write to temp file then atomic replace for rewrite operations. Append can be incomplete if power fails; validate line and retain backup/log.
## Alternative
RandomAccessFile fixed record format supports direct seek only when index/order gives record number; passId search still O(n) without an ID index. Padding wastes space.
