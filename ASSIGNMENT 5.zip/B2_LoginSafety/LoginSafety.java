import java.sql.*;
public class LoginSafety { // Demonstrates parameter binding; connect to a local test DB using your own credentials.
 static boolean safeLogin(Connection c,String user,String pass)throws SQLException{String sql="SELECT id FROM users WHERE id=? AND pwd=?";try(PreparedStatement ps=c.prepareStatement(sql)){ps.setString(1,user);ps.setString(2,pass);try(ResultSet rs=ps.executeQuery()){return rs.next();}}}
 public static void main(String[] args){System.out.println("PreparedStatement binds user values as data, not SQL syntax.");System.out.println("Test normal valid and invalid credentials in your local test database.");}}
