import java.util.*;
public interface Dao<T,K> { boolean insert(T value); Optional<T> findById(K id); List<T> findAll(); boolean update(T value); boolean delete(K id); }
