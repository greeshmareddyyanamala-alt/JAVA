CREATE TABLE bus_pass (pass_id VARCHAR(30) PRIMARY KEY, reg_no VARCHAR(30), name VARCHAR(100), route_no INT, amount DOUBLE);
